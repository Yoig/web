document.addEventListener("DOMContentLoaded", () => {
  const cateButton = document.querySelector(".addCate");
  const tab = document.querySelector(".table");
  const list = document.querySelector(".list");
  const searchButton = document.querySelector(".searchButton");
  let categories = [];

  document.addEventListener("keypress", (e) => {
    if (e.keyCode == 13) {
      addTask(categories, list);
    }
  });

  cateButton.addEventListener("click", () => {
    addCate(tab, categories, list);
  });

  searchButton.addEventListener("click", () => {
    search(tab);
  });
});

function addTask(categories, list) {
  let input = document.querySelector(".task").value;

  if (input == 0) {
    alert("pole jest puste");
    return;
  }

  if (categories.length == 0) {
    alert("stwórz kategorie");
    return;
  } else {
    let selectedOption = list.options[list.selectedIndex]; //opcja wybrana
    let selectedText = selectedOption.text; //dane

    let category = document.querySelector(`.${selectedText}`);

    let paragraphs = category.querySelectorAll("p");
    for (let i = 0; i < paragraphs.length; i++) {
      if (paragraphs[i].innerText == input + "X🖌︎") {
        alert("podane zadanie już istnieje");
        return;
      }
    }

    let paragraph = document.createElement("p");
    paragraph.innerText = input;

    let removeButton = document.createElement("button");
    removeButton.innerText = "X";
    removeButton.onclick = remove;

    paragraph.appendChild(removeButton);

    let editButton = document.createElement("button");
    editButton.innerText = "🖌︎";
    editButton.onclick = edit;

    paragraph.appendChild(editButton);

    category.appendChild(paragraph);
  }
}

function remove(e) {
  let paragrath = e.target.parentElement;

  let parent = paragrath.parentElement;

  let sibling = e.target.nextElementSibling;

  paragrath.removeChild(sibling);
  paragrath.removeChild(e.target);

  parent.removeChild(paragrath);
}

function edit(e) {
  let paragraph = e.target.parentElement;

  let parent = paragraph.parentElement;
  let editAreas = parent.querySelectorAll("textarea");

  if (editAreas.length == 0) {
    let oldText = paragraph.outerText.replace("X🖌︎", "");

    editArea = document.createElement("textarea");
    editArea.innerText = oldText;
    editArea.classList = "editArea";
    parent.appendChild(editArea);
  } else {
    editArea = document.querySelector(".editArea");

    let newText = editArea.value;

    paragraph.innerText = newText;

    parent.removeChild(editArea);

    let removeButton = document.createElement("button");
    removeButton.innerText = "X";
    removeButton.onclick = remove;

    paragraph.appendChild(removeButton);

    let editButton = document.createElement("button");
    editButton.innerText = "🖌︎";
    editButton.onclick = edit;

    paragraph.appendChild(editButton);
  }
}

function addCate(tab, categories, list) {
  let Input = document.querySelector(".cate").value;

  if (Input == 0) {
    alert("pole jest puste");
  }

  for (let i = 0; i < categories.length; i++) {
    if (Input == categories[i]) {
      alert("podana kategoria już istnieje");
      return;
    }
  }

  if (categories.length == 0) {
    categories[0] = Input;
  } else {
    categories[categories.length] = Input;
  }

  let create1 = document.createElement("div");
  let create2 = document.createElement("h2");

  create1.classList = Input;
  create2.classList = Input + "h2";
  create2.innerText = Input;

  create1.appendChild(create2);
  tab.appendChild(create1);

  let option = document.createElement("option");
  option.innerText = Input;
  list.appendChild(option);
}

function search(tab) {
  let result = [];

  let input = document.querySelector(".searchBar");
  let paragraphs = tab.querySelectorAll("p");

  for (let i = 0; i < paragraphs.length; i++) {
    if (paragraphs[i].outerText.search(`${input.value}`) != -1) {
      if (result.lenght == 1) {
        result[0] = paragraphs[i];
        result[0].classList = "results";
        document.body.appendChild(result[0]);
      } else {
        result[1 + 1] = paragraphs[i];
        result[1 + 1].classList = "results";
        document.body.appendChild(result[1 + 1]);
      }
    }
  }
  let results = document.querySelectorAll(".results");
  if (results.length == 0) {
    alert("nie znaleziono zadania");
  }
}
